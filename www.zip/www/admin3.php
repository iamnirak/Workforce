<?php
    //include_once'dbconnect.php';
    //include_once'dbconnect.php';
    include "dbconnect.php";
    if (isset($_POST['status'])) {
      $status = $_POST['status'];
      $job_id = $_POST['job_id'];
      $sql="Update `jobs` SET status='$status' where id = '$job_id'";
      if(mysqli_query($conn, $sql)===True){
        echo "<script>alert('Status Updated Successfully')</script>";
      }
    }

?>


<!DOCTYPE html>
<html>
<head>
    <title></title>
    </head>
    
    <style>
        
        body {
  font-family: Arial, Helvetica, sans-serif;
}
        
    /* Header/Logo Title */
.jumbotron {
	 text-align: center;
    background-color: #f4511e;
    color: #fff;
    padding: 30px 25px;
    font-family: Montserrat, sans-serif;
  }
        
        /* Navigation Bar */
        
        .navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
        
        /* Add a background color to the active dot/circle */
.active, .dot:hover {
  background-color: #717171;
}
        
        .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}
        
        .p{
          font-size: 40px;  
            
        }
        #customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}

#logo {
  display: inline-block;
  margin: 15px; 
  float: left;
  height: 100px;
  width: auto; 
  border-radius: 50%; 
}

    </style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script src="jquery.blueberry.js"></script>
<script>
$(window).load(function() {
$('.blueberry').blueberry();
});
</script>

<body>
    
    <div class="jumbotron text-center">
  <h1>Specialised Staffing Solution Pty LTD</h1> 
  <p>We help businesses thrive</p>    
</div>
    
    <div class="navbar">
  <a  href="Home1.php">Home</a>
    
 
            <a  class="active" href="admin3.php">My Work</a>
			<a  href="home.php">Log Out</a>

</div> 
    


 
   <b>  <p style="color:red;">Total Booking Requests.</p> </b>     
   <?php
   session_start(); 
   $staff_id = $_SESSION['id'];
   $sql = "SELECT * FROM jobs where staff_id = '$staff_id'";
   $result = mysqli_query($conn, $sql);
   $resultCheck = mysqli_num_rows($result);?>

   <table class="table table-bordered" id="customers">
   <thead>
     <th>First Name</th>
     <th>Last Name</th>
     <th>Mobile No</th>
     <th>Email</th>
     <th>Service</th>
     <th>Staff</th>
     <th>Date</th>
     <th>Start</th>
     <th>Duration</th>
     <th>Address</th>
     <th>Consideration</th>
     <th>Progress</th>
	 
   </thead>
   <tbody>
    
   <?php if( $resultCheck > 0)  {
        while ($row1 = mysqli_fetch_assoc($result)){
          $id = $row1['job_id'];
          $sql1 = "SELECT * FROM booking where id = '$id'";
          $result1 = mysqli_query($conn, $sql1);
          $resultCheck1 = mysqli_num_rows($result1);

          if( $resultCheck1 > 0)  {
            while ($row = mysqli_fetch_assoc($result1)){?>             
            <tr>
              <td><?= $row['fname']?></td>
              <td><?= $row['lname']?></td>
              <td><?= $row['mobile']?></td>
              <td><?= $row['email']?></td>
              <td><?= $row['service']?></td>
              <td><?= $row['staff']?></td>
              <td><?= $row['date']?></td>
              <td><?= $row['start']?></td>
              <td><?= $row['duration']?></td>
              <td><?= $row['address']?></td>
              <td><?= $row['consideration']?></td>
             <?php if($row1['status'] == 'Pending'){?>
			  
              <form action = "#" method="post">
                <input type="hidden" name="job_id" value="<?=$row1['id'];?>">
              <td>
                <select name="status">
                    <option value="Completed">Completed</option>
                    
               </select>
			   
			  
			   
               | <input type="submit" name="assign" value="Submit">  </td>
              </form>
              <?php } else { ?>
                <td><?= $row1['status'];?></td>
             <?php } ;?>
            </tr>
            <?php }}}} ?>
            </tbody>
          </table>



    
	
	
	
	<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
a {
  text-decoration: none;
  display: inline-block;
  padding: 8px 16px;
}

a:hover {
  background-color: #ddd;
  color: black;
}

.previous {
  background-color: #f1f1f1;
  color: black;
}

.next {
  background-color: #04AA6D;
  color: white;
}

.round {
  border-radius: 50%;
}
</style>
</head>
<body>



<!-- <a href="Accept.php" class="next">Accept</a>
<a href="Reject.php" class="next">Reject</a> -->

  
</body>
	
	<br>
	<br>
	<br>
	<br>
	<br>
	
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>

footer {
  text-align: center;
  padding: 3px;
  background-color: #aaaa;
  color: white;
}
</style>


<footer>
  <p>Copyright © 2021 | Specialised Staffing Solutions Pty Ltd |<br>
 
</footer>



	</body>
</html>
