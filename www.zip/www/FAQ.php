<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Style the body */
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.jumbotron {
	 text-align: center;
    background-color: #f4511e;
    color: #fff;
    padding: 30px 25px;
    font-family: Montserrat, sans-serif;
  }

/* Page Content */
.content {padding:20px;}
#logo {
  display: inline-block;
  margin: 15px; 
  float: left;
  height: 100px;
  width: auto; 
  border-radius: 50%; 
}


</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script src="jquery.blueberry.js"></script>
<script>
$(window).load(function() {
$('.blueberry').blueberry();
});
</script>

</head>
<body>
<body>
<header>
<a href="http://localhost/www/Home.php"><img id="logo" src="logo.png"></a>
<nav
</head>
<body>
<div class="jumbotron text-center">
  <h1>Specialised Staffing Solution Pty LTD</h1> 
  <p>We help businesses thrive</p>    
</div>


<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

    /* Add a background color to the active dot/circle */
.active, .dot:hover {
  background-color: #717171;
}
    
.navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
    
    /* This is for image gallery*/
    
    div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}


.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}



.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
   
    .h1
    {
        text-decoration-color: crimson;
    }
    
    
</style>




<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #f4511e;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>


















</head>

<body>

<div class="navbar">
  <a  href="Home.php">Home</a>
    <a class="active" href="Service.php">Our Services</a>
  <a  href="Book.php">Booking</a>
  <a href="Contact.php"> Contact Us</a> 
    <a href="Signup.php">Sign Up</a>
            

</div> 

<br>
<br>
<br>




<h1 style="text-align:center">FAQ</h1>
 
 
<br>

<b> Q: Who do I contact if I have a problem? </b> <br>
If you have a problem with your booking you can contact us at any time by
emailing specializedsoulution@gmail.com and we will deal with your enquiry as quickly as possible.
Alternatively, you can speak to a member of the Bookings support team over the phone by calling
+610410402702.<br><br><br>

<b> Q: Will my booking system be mobile-friendly? </b> <br><br>
Yes. System Bookings is aware that many customers like to make bookings directly from their
smartphones and tablets. This is especially important with the high proportion of online traffic
originating from mobile devices. This is why we ensure all of the booking systems we create are fully
responsive in design. You will also be able to login to your booking system and access its data using your
mobile phone from any location in the world, as long as you have a connection to the internet.
<br><br><br>
<b> Q: What is your return policy? </b><br><br>
A: We allow returns of all items within 30 days of your order date. Just send us an email with your order
number and we will send you a return label.<br><br><br>

<b>Q: Can I limit how far ahead clients can book an appointment?</b><br><br>
Yes, you can choose how far in advance clients can book, reschedule, or cancel their appointments.
Additionally, you can also set a limit on the number of bookings that can be made per client in a
day/month/year.<br><br>

<b>Q: Can different staff member have their own login?</b><br><br><br>
Yes, in Appointee, you can enable separate staff logins for your staff members so that they can manage
their upcoming bookings and schedule. The admin can assign staff and manager roles to team members
as well. The staff will only be able to view and edit their own bookings and will not have access to any
other staff schedules, whereas the manager can view/manage the bookings and schedule of all staff
members.<br><br><br>

<b>Q: Can I set specific availability for certain services and not a regular one?</b><br><br>
Yes, you can set specific availabilities for different services in the system. If certain services don’t have a
weekly recurring availability, you can set irregular times for those services (like, keratin treatment is
available at 2 PM on this Sunday). Irregular times can also be added in addition to the regular availability
hours of a service.
<br><br><br>




<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

footer {
  text-align: center;
  padding: 3px;
  background-color: #aaaa;
  color: white;
}
</style>


<footer>
  <p>Copyright © 2021 | Specialised Staffing Solutions Pty Ltd |<br>
 
</footer>

</body>
</html>
