<?php



session_start(); 
include "dbconnect.php";
if (isset($_POST['email']) && isset($_POST['psw'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$fullname = validate($_POST['email']);
	$psw = validate($_POST['psw']);

	if ($fullname =='') {
		header("Location: Home.php?error=User Name is required");
	    exit();
	}else if($psw ==''){
        header("Location: Home.php?error=Password is required");
	    exit();
	}else{
		$sql = "SELECT * FROM admin WHERE email='$fullname' AND psw='$psw'";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) === 1) {
            
            //$_SESSION['fullname'] = $fullname;
			$row = mysqli_fetch_assoc($result);
            if ($row['email'] == $fullname && $row['psw'] == $psw) {
            	$_SESSION['fullname'] = $row['Fullname'];
            //	$_SESSION['name'] = $row['name'];
            //	$_SESSION['id'] = $row['id'];
            	header("Location: Home2.php");
		        exit();
            }
            else{
				header("Location: Home.php?error=Incorect User name or password");
		        exit();
			}
		}else{
			header("Location: Home.php?error=Incorect User name or password");
	        exit();
		}
	}
	
}else{
	header("Location: Home2.php");
	exit();
}


