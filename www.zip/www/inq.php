
<?php
    //include_once'dbconnect.php';
include "dbconnect.php";
if (isset($_POST[''])) {
 // $employee_id = $_POST['assign_to'];
  //$job_id = $_POST['job_id'];
//$sql="INSERT INTO `jobs` (`job_id`, `staff_id`) VALUES ('$job_id','$employee_id')";
  if(mysqli_query($conn, $sql)===True){
    //echo "<script>alert('Job Assigned Successfully')</script>";
  }
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
<title>Enquires</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Style the body */
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.jumbotron {
	 text-align: center;
    background-color: #f4511e;
    color: #fff;
    padding: 30px 25px;
    font-family: Montserrat, sans-serif;
  }

/* Page Content */
.content {padding:20px;}
#logo {
  display: inline-block;
  margin: 15px; 
  float: left;
  height: 100px;
  width: auto; 
  border-radius: 50%; 
}

</style>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script src="jquery.blueberry.js"></script>
<script>
$(window).load(function() {
$('.blueberry').blueberry();
});
</script>
</head>
<body>
<header>
<a href="http://localhost/www/Home.php"><img id="logo" src="logo.png"></a>
<nav
</head>
<body>

<div class="jumbotron text-center">
  <h1>Specialised Staffing Solution Pty LTD</h1> 
  <p>We help businesses thrive</p>    
</div>


<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

    /* Add a background color to the active dot/circle */
.active, .dot:hover {
  background-color: #717171;
}
    
.navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
    
    /* This is for image gallery*/
    
    div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}


.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}



.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
   
    .h1
    {
        text-decoration-color: crimson;
    }
    
    
</style>




<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #f4511e;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}



table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 40%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}


</style>
</head>


















</head>

<body>

<div class="navbar">
  <a class="active" href="Home2.php">Home</a>
    <a   href="dashboard.php">Dashboard</a>
            <a   href="admin4.php">Assign Work</a>
			  <a   href="inq.php">Enquires</a>
<a  href="home.php">Log Out</a>
            

</div> 

<br>
<br>
<br>





 
    </div>
  </div>
</div>



  <h1 style="text-align:left">Enquires</h1>    
   <?php
   $sql = "SELECT * FROM contact;";
   $result = mysqli_query($conn, $sql);
   $resultCheck = mysqli_num_rows($result);
  
    
   if( $resultCheck > 0)  {?>
       
	   
	
	   
	   
	   
	   
	   
	   
	   
	   
        <table class="table table-bordered" id="id">
          <thead>
            <th>First Name</th> 
            <th>Last Name</th>
            <th>Email</th>
            <th>Country</th>
            <th>Subject</th>
            <th>Action</th>
          </thead>
          <tbody>
          <?php while ($row = mysqli_fetch_assoc($result)){
             $job_id = $row['id'];
             $jobs = "SELECT * from jobs where job_id='$job_id'";
             $result2 = mysqli_query($conn, $jobs);
             $resultCheck2 = mysqli_num_rows($result2);

             if($resultCheck2  > 0){

             }else{

             $staff = "SELECT * from signup";
             $result1 = mysqli_query($conn, $staff);
             $resultCheck1 = mysqli_num_rows($result1);
            ?>
            <tr>
              <td><?= $row['firstname']?></td>
              <td><?= $row['lastname']?></td>
              <td><?= $row['Mobile']?></td>
              <td><?= $row['country']?></td>
              <td><?= $row['subject']?></td>
            <td><a href="https://mail.google.com/mail/u/0/#inbox?compose=new">Response</a></td>
              </form>
            </tr>
			
			
			
			
			</tbody>
        </table>
            <?php }} ?>
          
   <?php }
   
 
?>


<br>







<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>





<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

footer {
  text-align: center;
  padding: 3px;
  background-color: #aaaa;
  color: white;
}
</style>


<footer>
  <p>Copyright © 2021 | Specialised Staffing Solutions Pty Ltd |<br>
 
</footer>

</body>
</html>
