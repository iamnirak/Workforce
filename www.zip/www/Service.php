<!DOCTYPE html>
<html lang="en">
<head>
<title>Services</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Style the body */
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.jumbotron {
	 text-align: center;
    background-color: #f4511e;
    color: #fff;
    padding: 30px 25px;
    font-family: Montserrat, sans-serif;
  }

/* Page Content */
.content {padding:20px;}
#logo {
  display: inline-block;
  margin: 15px; 
  float: left;
  height: 100px;
  width: auto; 
  border-radius: 50%; 
}

</style>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script src="jquery.blueberry.js"></script>
<script>
$(window).load(function() {
$('.blueberry').blueberry();
});
</script>
</head>
<body>
<header>
<a href="http://localhost/www/Home.php"><img id="logo" src="logo.png"></a>
<nav
</head>
<body>

<div class="jumbotron text-center">
  <h1>Specialised Staffing Solution Pty LTD</h1> 
  <p>We help businesses thrive</p>    
</div>


<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

    /* Add a background color to the active dot/circle */
.active, .dot:hover {
  background-color: #717171;
}
    
.navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
    
    /* This is for image gallery*/
    
    div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}


.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}



.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
   
    .h1
    {
        text-decoration-color: crimson;
    }
    
    
</style>




<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #f4511e;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>


















</head>

<body>

<div class="navbar">
  <a  href="Home.php">Home</a>
    <a class="active" href="Service.php">Our Services</a>
  <a  href="Book.php">Booking</a>
  <a href="Contact.php"> Contact Us</a> 
    <a href="Signup.php">Sign Up</a>
	<a href="faq.php">FAQ</a>
            

</div> 

<br>
<br>
<br>




<h1 style="text-align:center">Our Services</h1>
 
 <p style="text-align:center;">Based on the customers demand we corporate catering services that will impress your guests. Our services include both drop-off orders as well as staffed events.

Whether entertaining family, friends, colleagues or clients, we’ll provide you with beautiful food and service that sparkles, no matter what the occasion. We offer the best catering Sydney has to offer.As one of leading caterers, Flavours Catering + Events is committed to delighting its clientele with inspiring flavours, innovative concepts and an unsurpassed level of service. Our experience, knowledge, resources and passion translate into truly special events with fabulous food.</p>
  
      

 <br>
 <br>
    

<div class="row">
  <div class="column">
    <div class="card">
      <img src="https://images.unsplash.com/photo-1444201983204-c43cbd584d93?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1050&q=80" alt="Jane" style="width:100%">
      <div class="container">
        <h2>Residential Cleaning</h2>
        <p class="title"></p>
        <p>Specialised staffing solution has been in the cleaning business for over a decade and has grown to be the best cleaning service in Sydney.</p>
        <p></p>
        <p><button onclick="window.location.href='http://localhost/www/Book.php';" class="button">Book Now</button></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="https://images.unsplash.com/photo-1603712725038-e9334ae8f39f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1051&q=80" alt="Mike" style="width:100%">
      <div class="container">
        <h2>Commercial Cleaning</h2>
        <p class="title"></p>
        <p>Specialised staffing solution has been in cleaning business for over a decade and has grown to be the best service in Sydney.</p>
        <p></p>
        <p><button onclick="window.location.href='http://localhost/www/Book.php';"  class="button">Book Now</button></p>
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <img src="https://images.unsplash.com/photo-1480455454781-1af590be2a58?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80" alt="John" style="width:100%">
      <div class="container">
        <h2>Catering</h2>
        <p class="title"></p>
        <p>Based on the customers demand we corporate catering  that will impress your guests. Our services include both drop-off orders as well as staffed events.</p>
        <p></p>

        <p><button onclick="window.location.href='http://localhost/www/Book.php';" class="button">Book Now</button></p>
      </div>
    </div>
  </div>
</div>






<br>







<br>
<br>
<br>







<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

footer {
  text-align: center;
  padding: 3px;
  background-color: #aaaa;
  color: white;
}
</style>


<footer>
  <p>Copyright © 2021 | Specialised Staffing Solutions Pty Ltd |<br>
 
</footer>

</body>
</html>
