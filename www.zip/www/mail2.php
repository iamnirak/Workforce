<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';
// Include autoload.php file
require 'vendor/autoload.php';


//session_start();
 //header('location:Book1.php');

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$service = $_POST['service'];
$staff = $_POST['staff'];
$date = $_POST['date'];
$start = $_POST['start'];
$duration = $_POST['duration'];
$address = $_POST['address'];
$consideration = $_POST['consideration'];

$writtenmessage = " You Got new Booking";

$subject = "You Got new Booking";
$subject2 = "Your Message Submitted Successfully | WFM";
$message = "Client Name: ". $fname. "<br>Client email: ". $email."<br>Start Time: ". $start. "<br>Client Contact number: ". $mobile. "<br>Service: ". $service. "<br> Address: ". $address. "<br> Client Message: ". $consideration. "<br>\n\n" ;
$message2 = "Dear". $fname. "\n\n" ."Thank You for booking with us! We'll get back to you shortly"; 


//send email to website owner
$mail = new PHPMailer(true);
try {
  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = true;
  // Gmail ID which you want to use as SMTP server
  $mail->Username = 'specialisedsolution@gmail.com';
  // Gmail Password
  $mail->Password = 'Nirak@007';
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port = 587;

  // Email ID from which you want to send the email
  $mail->setFrom('specialisedsolution@gmail.com');
  // Recipient Email ID where you want to receive emails
  $mail->addAddress('specialisedsolution@gmail.com');

  $mail->isHTML(true);
  $mail->Subject = $subject;
  $mail->Body = $message;
  $mail->send();
} catch (Exception $e) {
  //$e->getMessage() ;
  echo '<script type="text/javascript">alert("Submission failed! Try again Later.") </script>';
}

//send email to User as well
$mailb = new PHPMailer(true);
try {
  $mailb->isSMTP();
  $mailb->Host = 'smtp.gmail.com';
  $mailb->SMTPAuth = true;
  // Gmail ID which you want to use as SMTP server
  $mailb->Username = 'specialisedsolution@gmail.com';
  // Gmail Password
  $mailb->Password = 'Nirak@007';
  $mailb->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mailb->Port = 587;

  // Email ID from which you want to send the email
  $mailb->setFrom('specialisedsolution@gmail.com');
  // Recipient Email ID where you want to receive emails
  $mailb->addAddress($email);

  $mailb->isHTML(true);
  $mailb->Subject = $subject2;
  $mailb->Body = $message2;
  $mailb->send();
} catch (Exception $e) {
  //$e->getMessage() ;
  
}