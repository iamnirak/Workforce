


<?php



//session_start();
//header('location:Home.php');



$fullname = $_POST['fullname'];
$address = $_POST['address'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$psw = $_POST['psw'];
$resume = $_POST['resume'];


// Database connection
	$conn = new mysqli('localhost','root','','wfm');
	if($conn->connect_error)
            {
                echo "$conn->connect_error";
                die("Connection Failed : ". $conn->connect_error);
            } 

    else {
		
            $sql="INSERT INTO `signup` (`fullname`, `address`, `mobile`, `email`,`psw`,`resume`) VALUES ('$fullname','$address','$mobile','$email','$psw','$resume')";
       


        if(mysqli_query($conn, $sql)===True){
                  header("Location: Signup1.php");
	  exit();
            
            echo "Registration successfully...";

        }else{
              echo  "You already used this email. Please try with different email."
                  .mysqli_error($conn);				
            }	

	   }		
		
		
		$conn->close();
        
    
	
	?>
	
	
	