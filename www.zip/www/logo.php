<!Doctype html>
<html lang="en">
<head>
<title> I_See_St4irs</title>
<meta name="Viewpoint" content="Width=device-width,initial-scale=1.0">
<link rel="stylsheet" href="blueberry.css"/>
<style type="text/css">

#logo {
  display: inline-block;
  margin: 15px; 
  float: left;
  height: 60px;
  width: auto; 
  border-radius: 50%; 
}


</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script src="jquery.blueberry.js"></script>
<script>
$(window).load(function() {
$('.blueberry').blueberry();
});
</script>
</head>
<body>
<header>
<a href="#"><img id="logo" src="https://www.bing.com/rp/i8zz8wRsGskqyyAyL7FshdOu1qs.jpg"></a>
<nav>
<a href="http://localhost/www/Home.php" id="menu-icon"></a>




</body>
</html>
