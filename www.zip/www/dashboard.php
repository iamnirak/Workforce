<?php
    //include_once'dbconnect.php';
include "dbconnect.php";
if (isset($_POST[''])) {
 // $employee_id = $_POST['assign_to'];
  //$job_id = $_POST['job_id'];
//$sql="INSERT INTO `jobs` (`job_id`, `staff_id`) VALUES ('$job_id','$employee_id')";
  if(mysqli_query($conn, $sql)===True){
    //echo "<script>alert('Job Assigned Successfully')</script>";
  }
}

?>










<!DOCTYPE html>
<html lang="en">
<head>
<title>Dashboard</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* Style the body */
body {
  font-family: Arial;
  margin: 0;
}

/* Header/Logo Title */
.jumbotron {
	 text-align: center;
    background-color: #f4511e;
    color: #fff;
    padding: 30px 25px;
    font-family: Montserrat, sans-serif;
  }

/* Page Content */
.content {padding:20px;}
#logo {
  display: inline-block;
  margin: 15px; 
  float: left;
  height: 100px;
  width: auto; 
  border-radius: 50%; 
}

</style>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script src="jquery.blueberry.js"></script>
<script>
$(window).load(function() {
$('.blueberry').blueberry();
});
</script>
</head>
<body>
<header>
<a href="http://localhost/www/Home.php"><img id="logo" src="logo.png"></a>
<nav
</head>
<body>

<div class="jumbotron text-center">
  <h1>Specialised Staffing Solution Pty LTD</h1> 
  <p>We help businesses thrive</p>    
</div>


<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

    /* Add a background color to the active dot/circle */
.active, .dot:hover {
  background-color: #717171;
}
    
.navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
    
    /* This is for image gallery*/
    
    div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}


.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}



.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
   
    .h1
    {
        text-decoration-color: crimson;
    }
    
    
</style>




<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #f4511e;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>


















</head>

<body>

<div class="navbar">
  <a class="active" href="Home1.php">Home</a>
    <a   href="dashboard.php">Dashboard</a>
            <a   href="admin4.php">Assign Work</a>
			  <a   href="inq.php">Enquires</a>
<a  href="home.php">Log Out</a>
            

</div> 


 

<br>
<br>
<h1 style="text-align:left"> &emsp;Staff</h1>
<br>
<br>
<br>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial;}

/* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}
</style>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 50%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

</head>
<body>


<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'London')">Cleaning</button>
  <button class="tablinks" onclick="openCity(event, 'Paris')">Catering</button>
  
</div>

<div id="London" class="tabcontent">
  <h3>Cleaning Staff</h3>
  <table>
  <tr>
    <th>Name</th>
    <th>Contact</th>
	<th>Email</th>
    <th>Day Available</th>
  </tr>
  <tr>
    <td>Maria Anders</td>
    <td>0410789765</td>
	<td>abc@gmail.com</td>
    <td>Sun, Tues and Sat</td>
  </tr>
  <tr>
    <td>Akash Sen</td>
    <td>0418937466</td>
	<td>abc@gmail.com</td>
    <td>Friday and Sunday</td>
  </tr>
  <tr>
    <td>Anil Ojha</td>
    <td>0417787353</td>
	<td>abc@gmail.com</td>
    <td>Monday and Tuesday</td>
  </tr>
  <tr>
    <td>Gaurav Adhikari</td>
    <td>0410407834</td>
	<td>abc@gmail.com</td>
    <td>Tuesday and Thursday</td>
  </tr>
 
</table>
</div>

<div id="Paris" class="tabcontent">
  <h3>Catering Satff</h3>
  <table>
  <tr>
    <th>Name</th>
    <th>Contact</th>
	<th>Email</th>
    <th>Day Available</th>
  </tr>
  <tr>
    <td>Kusum</td>
    <td>0410779765</td>
	<td>abc@gmail.com</td>
    <td>Tues and Sat</td>
  </tr>
  <tr>
    <td>Akash Gun</td>
    <td>0418677466</td>
	<td>abc@gmail.com</td>
    <td>Friday and Sunday</td>
  </tr>
  <tr>
    <td>Anil Raja</td>
    <td>0417787377</td>
	<td>abc@gmail.com</td>
    <td>Monday and Tuesday</td>
  </tr>
  <tr>
    <td>Ramesh Adhikari</td>
    <td>0410407224</td>
	<td>abc@gmail.com</td>
    <td>Tuesday and Thursday</td>
  </tr>
 
</table>
</div>



<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>
<br>
<br>
<br>


<br><br>
<br>
<br><br>
<br>
<br>
<h1 style="text-align:left"> &emsp;Feedback</h1>
<br>
<br>

 <?php
   $sql = "SELECT * FROM feed";
   $result = mysqli_query($conn, $sql);
   $resultCheck = mysqli_num_rows($result);
  
    
   if( $resultCheck > 0)  {?>
       

	   
        <table class="table table-bordered" id="id">
          <thead>
            <th>Email</th> 
            <th>Service</th>
            <th>Feedback</th>
            <th>Action</th>
          </thead>
          <tbody>
          <?php while ($row = mysqli_fetch_assoc($result)){
             $job_id = $row['id'];
             $jobs = "SELECT * from jobs where job_id='$job_id'";
             $result2 = mysqli_query($conn, $jobs);
             $resultCheck2 = mysqli_num_rows($result2);

             if($resultCheck2  > 0){

             }else{

             $staff = "SELECT * from staff";
             $result1 = mysqli_query($conn, $staff);
             $resultCheck1 = mysqli_num_rows($result1);
            ?>
            <tr>
              <td><?= $row['Email']?></td>
              <td><?= $row['Service']?></td>
              <td><?= $row['Feedback']?></td>
              
            <td><a href="https://mail.google.com/mail/u/0/#inbox?compose=new">Response</a></td>
              </form>
            </tr>
			
			
			
			
			</tbody>
        </table>
            <?php }} ?>
          
   <?php }
   
 
?>




<br>







<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

















<br><br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

footer {
  text-align: center;
  padding: 3px;
  background-color: #aaaa;
  color: white;
}
</style>


<footer>
  <p>Copyright © 2021 | Specialised Staffing Solutions Pty Ltd |<br>
 
</footer>

</body>
</html>
