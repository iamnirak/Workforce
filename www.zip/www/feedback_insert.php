<?php






$email = $_POST['email'];
$service = $_POST['service'];
$feedback = $_POST['feedback'];



// Database connection
	$conn = new mysqli('localhost','root','','WFM');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		
		$sql="INSERT INTO `feed` ( `email`, `service`, `feedback`) VALUES ('$email','$service','$feedback')"; 
							   
    }
	if(mysqli_query($conn, $sql)===True){
		
      header("Location: feedback1.php");
	  exit();

        echo "Feedback successfully Submitted.";
	
	}else
    {
          echo  "Error".mysqli_error($conn);				
		}	

			
		
		
		$conn->close();
	
	?>