<?php
    //include_once'dbconnect.php';
include "dbconnect.php";
if (isset($_POST['assign_to'])) {
  $employee_id = $_POST['assign_to'];
  $job_id = $_POST['job_id'];
  $sql="INSERT INTO `jobs` (`job_id`, `staff_id`) VALUES ('$job_id','$employee_id')";
  if(mysqli_query($conn, $sql)===True){
    echo "<script>alert('Job Assigned Successfully')</script>";
  }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
    </head>
    
    <style>
        
        body {
  font-family: Arial, Helvetica, sans-serif;
}
        
    /* Header/Logo Title */
.jumbotron {
	 text-align: center;
    background-color: #f4511e;
    color: #fff;
    padding: 30px 25px;
    font-family: Montserrat, sans-serif;
  }
        
        /* Navigation Bar */
        
        .navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
        
        /* Add a background color to the active dot/circle */
.active, .dot:hover {
  background-color: #717171;
}
        
        .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}
        
        .p{
          font-size: 40px;  
            
        }

#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
    </style>
<body>
    
    <div class="jumbotron text-center">
  <h1>Specialised Staffing Solution Pty LTD</h1> 
  <p>We help businesses thrive</p>    
</div>
    
    <div class="navbar">
  <a  href="Home2.php">Home</a>
    
 
           
    <a   href="dashboard.php">Dashboard</a>
            <a   href="admin4.php">Assign Work</a>
			  <a   href="inq.php">Enquires</a>
<a  href="home.php">Log Out</a>

</div> 
    


 
   <b>  <p style="color:red;">Total Booking Requests.</p> </b>     
   <?php
   $sql = "SELECT * FROM booking;";
   $result = mysqli_query($conn, $sql);
   $resultCheck = mysqli_num_rows($result);
  
    
   if( $resultCheck > 0)  {?>
       
        <table class="table table-bordered" id="customers">
          <thead>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Mobile No</th>
            <th>Email</th>
            <th>Service</th>
            <th>Staff</th>
            <th>Date</th>
            <th>Start</th>
            <th>Duration</th>
            <th>Address</th>
            <th>Consideration</th>
            <th>Assign To</th>
            <th>Action</th>
          </thead>
          <tbody>
          <?php while ($row = mysqli_fetch_assoc($result)){
             $job_id = $row['id'];
             $jobs = "SELECT * from jobs where job_id='$job_id'";
             $result2 = mysqli_query($conn, $jobs);
             $resultCheck2 = mysqli_num_rows($result2);

             if($resultCheck2  > 0){

             }else{

             $staff = "SELECT * from signup";
             $result1 = mysqli_query($conn, $staff);
             $resultCheck1 = mysqli_num_rows($result1);
            ?>
            <tr>
              <td><?= $row['fname']?></td>
              <td><?= $row['lname']?></td>
              <td><?= $row['mobile']?></td>
              <td><?= $row['email']?></td>
              <td><?= $row['service']?></td>
              <td><?= $row['staff']?></td>
              <td><?= $row['date']?></td>
              <td><?= $row['start']?></td>
              <td><?= $row['duration']?></td>
              <td><?= $row['address']?></td>
              <td><?= $row['consideration']?></td>
              <form action = "#" method="post">
                <input type="hidden" name="job_id" value="<?=$row['id'];?>">
              <td>
              <select name="assign_to">
              <?php if( $resultCheck > 0)  {
                while ($row1 = mysqli_fetch_assoc($result1)){
                  if($row1['fullname'] !=''){
                  ?>
                    <option value="<?= $row1['id'];?>"><?=$row1['fullname'];?></option>
                <?php }}} ?>

              </select>
              </td>
              <td><input type="submit" name="assign" value="Assign"></td>
              </form>
            </tr>
            <?php }} ?>
          </tbody>
        </table>
   <?php }
   
 
?>

<br><br><br>
<b>  <p style="color:red;">Assigned Work Detail</p> </b>     
   <?php
   $sql = "SELECT * FROM booking;";
   $result = mysqli_query($conn, $sql);
   $resultCheck = mysqli_num_rows($result);
  
    
   if( $resultCheck > 0)  {?>
       
        <table class="table table-bordered" id="customers">
          <thead>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Mobile No</th>
            <th>Email</th>
            <th>Service</th>
            <th>Staff</th>
            <th>Date</th>
            <th>Start</th>
            <th>Duration</th>
            <th>Address</th>
            <th>Consideration</th>
            <th>Assign To</th>
            <th>Progress</th>
			
          </thead>
          <tbody>
          <?php while ($row = mysqli_fetch_assoc($result)){
             $job_id = $row['id'];
             $jobs = "SELECT * from jobs where job_id='$job_id'";
             $result1 = mysqli_query($conn, $jobs);
             $resultCheck1 = mysqli_num_rows($result1);
            if( $resultCheck1 > 0)  {
              while ($row1 = mysqli_fetch_assoc($result1)){
                $staff_id = $row1['staff_id'];
                $jobs = "SELECT * from signup where id='$staff_id'";
                $result2 = mysqli_query($conn, $jobs);
                $resultCheck2 = mysqli_num_rows($result1);
                while ($row2 = mysqli_fetch_assoc($result2)){
                  $staff_name = $row2['fullname'];
                }

            ?>
            <tr>
              <td><?= $row['fname']?></td>
              <td><?= $row['lname']?></td>
              <td><?= $row['mobile']?></td>
              <td><?= $row['email']?></td>
              <td><?= $row['service']?></td>
              <td><?= $row['staff']?></td>
              <td><?= $row['date']?></td>
              <td><?= $row['start']?></td>
              <td><?= $row['duration']?></td>
              <td><?= $row['address']?></td>
              <td><?= $row['consideration']?></td>
              <td><?=  $staff_name ;?></td>
              <td><?= $row1['status']?></td>
             
            </tr>
            <?php } }}?>
          </tbody>
        </table>
   <?php }
   
 
?>
  
   
	
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>

footer {
  text-align: center;
  padding: 3px;
  background-color: #aaaa;
  color: white;
}
</style>


<footer>
  <p>Copyright © 2021 | Specialised Staffing Solutions Pty Ltd |<br>
 
</footer>



	</body>
</html>
