-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2021 at 08:59 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wfm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Fullname` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `psw` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Fullname`, `address`, `mobile`, `email`, `psw`) VALUES
('Admin', 'Oceanview Dr', '0410402345', 'itsnirak@gmail.com', 'Admin@007');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(50) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `mobile` int(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `service` varchar(49) NOT NULL,
  `staff` int(50) NOT NULL,
  `date` date NOT NULL,
  `start` varchar(34) NOT NULL,
  `duration` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `consideration` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `fname`, `lname`, `mobile`, `email`, `service`, `staff`, `date`, `start`, `duration`, `address`, `consideration`) VALUES
(57, 'Kushum', 'pathak', 411485217, 'iamnirakpoudel@gmail.com', 'cleaning', 6, '2021-09-24', '3 pm', '2 Hours', '58 Terrigal ESP', ''),
(59, 'Akash', 'Sen', 411485217, 'iamnirakpoudel@gmail.com', 'cleaning', 4, '2021-09-24', '3 pm', '2 Hours', '58 Terrigal ESP', ''),
(61, 'Akash', 'nirak', 411485217, 'iamnirakpoudel@gmail.com', 'cleaning', 10, '2021-09-17', '3 pm', '2 Hours', '58 Terrigal ESP', ''),
(62, 'Kushum', 'nirak', 411485217, 'iamnirakpoudel@gmail.com', 'cleaning', 0, '0000-00-00', '', '2 Hours', '58 Terrigal ESP', ''),
(63, 'Kushum', 'nirak', 411485217, 'iamnirakpoudel@gmail.com', 'cleaning', 0, '0000-00-00', '', '2 Hours', '58 Terrigal ESP', ''),
(64, 'Kushum', 'nirak', 411485217, 'iamnirakpoudel@gmail.com', 'cleaning', 0, '0000-00-00', '', '2 Hours', '58 Terrigal ESP', ''),
(65, 'Kushum', 'nirak', 411485217, 'iamnirakpoudel@gmail.com', 'cleaning', 0, '0000-00-00', '', '2 Hours', '58 Terrigal ESP', ''),
(66, 'Kushum', 'nirak', 411485217, 'iamnirakpoudel@gmail.com', 'cleaning', 0, '0000-00-00', '', '2 Hours', '58 Terrigal ESP', ''),
(67, 'Nirak', 'Poudel', 411485217, 'iamnirakpoudel@gmail.com', 'cleaning', 5, '2021-09-30', '5 pm', '2 Hours', '58 Terrigal ESP', '');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(50) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `Mobile` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `subject` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `firstname`, `lastname`, `Mobile`, `country`, `subject`) VALUES
(0, 'Kusum', 'Pathak', 'iamnirakpoudel@gmail.com', 'australia', 'sdfg');

-- --------------------------------------------------------

--
-- Table structure for table `feed`
--

CREATE TABLE `feed` (
  `id` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Service` text NOT NULL,
  `Feedback` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feed`
--

INSERT INTO `feed` (`id`, `Email`, `Service`, `Feedback`) VALUES
(0, 'iamnirakpoudel@gmail.com', 'cleaning', 'Nice');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `staff_id` int(100) NOT NULL DEFAULT 0,
  `job_id` int(100) NOT NULL DEFAULT 0,
  `status` varchar(100) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `staff_id`, `job_id`, `status`) VALUES
(30, 2, 58, 'Completed'),
(31, 1, 59, 'Completed'),
(32, 2, 43, 'Completed'),
(33, 8, 45, 'Completed'),
(34, 1, 46, 'Pending'),
(35, 1, 46, 'Pending'),
(36, 2, 57, 'Completed'),
(37, 8, 67, 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobile` int(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `psw` varchar(49) NOT NULL,
  `resume` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `fullname`, `address`, `mobile`, `email`, `psw`, `resume`) VALUES
(1, 'Nirak Poudel', '58 Terrigal ESP', 411485217, 'iamnirakpoudel@gmail.com', 'abcdef', ''),
(2, 'Akash', '58 Terrigal ESP', 411485217, 'Nirak Poudel', '56789', ''),
(8, 'Anil Ojha', 'U 1 74-78 OCEANVIEW DR', 98765432, 'Anil@gmail.com', '123', ''),
(10, 'nirak', '58 Terrigal ESP', 411485217, 'jhdhf@gmail.com', 'asdfghj', ''),
(11, 'nirak', '58 Terrigal ESP', 411485217, 'fdghjhhf@gmail.com', 'dfdghjkjl', ''),
(12, 'Laxman', 'U 1 74-78 OCEANVIEW DR', 411485217, 'admin@gmail.com', 'Admin@007', '');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Job` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `Name`, `Email`, `Phone`, `Address`, `Job`) VALUES
(1, 'Ammar', 'staff@gmail.com', '12345', 'Test', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
